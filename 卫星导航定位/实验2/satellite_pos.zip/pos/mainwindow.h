#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "qlineedit.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_pushButton_clicked();
    bool check();
    void fillData();
    void caculate();
    void on_b_fillData_clicked();

    void HalfLong();
    void TrueAveAngularV();
    void SatelliteClockError();
    void EphemerisBeginTime();
    void AveAnomaly();
    void EccAnomaly();
    void TruAnomaly();
    void UpPFA();
    void AdjustedOfUpPFA();
    void AdjustedOfRadiusVector();
    void AdjustedOfDip();
    void TrueUpPFA();
    void TrueRadiusVector();
    void TrueDip();
    void TrueAscendingLongitude();
    void pos();
    void ECEF();

private:
    Ui::MainWindow *ui;
    QLineEdit *baseTimeText; // 星历基准时间
    QLineEdit *timeText;    // 观测时间
    QLineEdit *sqrtHalfLongText;          //轨道半长轴的平方根
    QLineEdit *eccentricityText;          //轨道离心率
    QLineEdit *dipText;                   //倾角
    QLineEdit *ascendingLongitudeText;    //升交点经度
    QLineEdit *perigeeArgText;            //近地点幅角
    QLineEdit *aveApproachAngleText;      //平均近点角
    QLineEdit *changeRateOfdipText;       //倾角变化率
    QLineEdit *changeRateOfAscendingLongitudeText;    //升交点经度变化率
    QLineEdit *adjustedOfAveAngularVText;             //平均角速度的校正值
    QLineEdit *adjustedOfLatitudeArgCosText;         //纬度幅角余弦的校正值
    QLineEdit *adjustedOfLatitudeArgSinText;         //纬度幅角正弦的校正值
    QLineEdit *adjustedOfRadiusCosText;   //轨道半径余弦的校正值
    QLineEdit *adjustedOfRadiusSinText;   //轨道半径正弦的校正值
    QLineEdit *adjustedOfDipCosText;          //倾角余弦的校正值
    QLineEdit *adjustedOfDipSinText;          //倾角正弦的校正值
    QLineEdit *secondText;              // 秒数据
    QLineEdit *clockCorrection0Text;    // 时钟修正0
    QLineEdit *clockCorrection1Text;
    QLineEdit *clockCorrection2Text;

    QLineEdit *halfLongText;
    QLineEdit *trueAveAngularVText;
    QLineEdit *satelliteClockErrorText;
    QLineEdit *ephemerisBeginTimeText;
    QLineEdit *aveAnomalyText;
    QLineEdit *eccAnomalyText;
    QLineEdit *truAnomalyText;
    QLineEdit *upPFAText;
    QLineEdit *adjustedOfUpPFAText;
    QLineEdit *adjustedOfRadiusVectorText;
    QLineEdit *adjustedOfDipText;
    QLineEdit *trueUpPFAText;
    QLineEdit *trueRadiusVectorText;
    QLineEdit *trueDipText;
    QLineEdit *trueAscendingLongitudeText;
    QLineEdit *posXText;
    QLineEdit *posYText;
    QLineEdit *ECEFxText;
    QLineEdit *ECEFyText;
    QLineEdit *ECEFzText;


private:
    const double PI = 3.1415926535897932384626;
    const double EGC = 3.986005e14;       //椭球引力常数
    const double RAV = 7.2921151467e-5;   //地球自转角速度
    double baseTime = 0; //星历基准时间
    double time = 0;
    double sqrtHalfLong = 0;          //轨道半长轴的平方根
    double eccentricity = 0;          //轨道离心率
    double dip = 0;                   //倾角
    double ascendingLongitude = 0;    //升交点经度
    double perigeeArg = 0;            //近地点幅角
    double aveApproachAngle = 0;      //平均近点角
    double changeRateOfdip = 0;       //倾角变化率
    double changeRateOfAscendingLongitude = 0;    //升交点经度变化率
    double adjustedOfAveAngularV = 0;             //平均角速度的校正值
    double adjustedOfLatitudeArgCos = 0;         //纬度幅角余弦的校正值
    double adjustedOfLatitudeArgSin = 0;         //经度幅角正弦的校正值
    double adjustedOfRadiusCos = 0;   //轨道半径余弦的校正值
    double adjustedOfRadiusSin = 0;   //轨道半径正弦的校正值
    double adjustedOfDipCos = 0;          //倾角余弦的校正值
    double adjustedOfDipSin = 0;          //倾角正弦的校正值
    double second = 0;
    double clockCorrection0 = 0;
    double clockCorrection1 = 0;
    double clockCorrection2 = 0;

    double halfLong;              //半长轴
    double trueAveAngularV;       //经校正的平均角速度
    double satelliteClockError;   //卫星钟差
    double ephemerisBeginTime;        //星历起算时间
    double aveAnomaly;            //平均近点角
    double eccAnomaly;            //偏心近点角
    double truAnomaly;            //真近点角
    double upPFA;                     //升交距角
    double adjustedOfUpPFA;       //升交距角校正值
    double trueUpPFA;             //经矫正的升交距角
    double adjustedOfRadiusVector;//向径校正值
    double trueRadiusVector;      //经校正的向径
    double adjustedOfDip;         //倾角校正值
    double trueDip;               //经校正的倾角
    double trueAscendingLongitude;//经校正的升交点经度

    double posX;
    double posY;
};
#endif // MAINWINDOW_H
