#include "mainwindow.h"
#include "./ui_mainwindow.h"

#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    {

        setWindowTitle("卫星位置计算");
        setWindowOpacity(0.96);
        //setStyleSheet ("border:1px groove gray;border-radius:10px;");//padding:2px 4px;


    }
    ui->setupUi(this);
    timeText = ui->timeText;                // 观测时间
    baseTimeText = ui->baseTimeText;        // 星历基准时间
    sqrtHalfLongText = ui->sqrtHalfLongText;// 轨道半长轴平方根
    eccentricityText = ui->eccentricityText;// 轨道离心率  0.0053100715158500003
    dipText = ui->dipText;                  // 倾角
    ascendingLongitudeText = ui->ascendingLongitudeText; // 升交点经度  -2.9080127721900002
    changeRateOfAscendingLongitudeText = ui->changeRateOfAscendingLongitudeText; // 升交点经度变化率
    adjustedOfAveAngularVText = ui->adjustedOfAveAngularVText;          // 平均角速度的校正值
    adjustedOfLatitudeArgCosText = ui->adjustedOfLatitudeArgCosText;    // 纬度幅角余弦的校正值
    adjustedOfLatitudeArgSinText = ui->adjustedOfLatitudeArgSinText;    // 纬度幅角正弦的校正值
    adjustedOfRadiusCosText = ui->adjustedOfRadiusCosText;  // 轨道半径余弦的校正值
    adjustedOfRadiusSinText = ui->adjustedOfRadiusSinText;  // 轨道半径正弦的校正值
    adjustedOfDipCosText = ui->adjustedOfDipCosText;    // 倾角余弦的校正值
    adjustedOfDipSinText = ui->adjustedOfDipSinText;    // 倾角正弦的校正值
    changeRateOfdipText = ui->changeRateOfdipText;  // 倾角变化率
    perigeeArgText = ui->perigeeArgText;    // 近地点幅角    -1.6819446292500000
    aveApproachAngleText = ui->aveApproachAngleText;    // 平均近点角   1.2263973009600000
    secondText = ui->secondText;    // 秒数据
    clockCorrection0Text = ui->clockCorrection0Text;    // 时钟修正0
    clockCorrection1Text = ui->clockCorrection1Text;
    clockCorrection2Text = ui->clockCorrection2Text;
    // 未知量Text
    halfLongText = ui->halfLongText;
    trueAveAngularVText = ui->trueAveAngularVText;
    satelliteClockErrorText = ui->satelliteClockErrorText;
    ephemerisBeginTimeText = ui->ephemerisBeginTimeText;
    aveAnomalyText = ui->aveAnomalyText;
    eccAnomalyText = ui->eccAnomalyText;
    truAnomalyText = ui->truAnomalyText;
    upPFAText = ui->upPFAText;
    adjustedOfUpPFAText = ui->adjustedOfUpPFAText;
    adjustedOfRadiusVectorText = ui->adjustedOfRadiusVectorText;
    adjustedOfDipText = ui->adjustedOfDipText;
    trueUpPFAText = ui->trueUpPFAText;
    trueRadiusVectorText = ui->trueRadiusVectorText;
    trueDipText = ui->trueDipText;
    trueAscendingLongitudeText = ui->trueAscendingLongitudeText;
    posXText = ui->posXText;
    posYText = ui->posYText;
    ECEFxText = ui->ECEFxText;
    ECEFyText = ui->ECEFyText;
    ECEFzText = ui->ECEFzText;
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::check()
{
    if(baseTimeText->text().isEmpty()) return false;
    else baseTime =  baseTimeText->text().toDouble();

    if(timeText->text().isEmpty()) return false;
    else time =  timeText->text().toDouble();

    if(sqrtHalfLongText->text().isEmpty()) return false;
    else sqrtHalfLong = sqrtHalfLongText->text().toDouble();

    if(eccentricityText->text().isEmpty()) return false;
    else eccentricity = eccentricityText->text().toDouble();

    if(dipText->text().isEmpty()) return false;
    else dip = dipText->text().toDouble();

    if(ascendingLongitudeText->text().isEmpty()) return false;
    else ascendingLongitude = ascendingLongitudeText->text().toDouble();

    if(perigeeArgText->text().isEmpty()) return false;
    else perigeeArg = perigeeArgText->text().toDouble();

    if(aveApproachAngleText->text().isEmpty()) return false;
    else aveApproachAngle = aveApproachAngleText->text().toDouble();

    if(changeRateOfdipText->text().isEmpty()) return false;
    else changeRateOfdip = changeRateOfdipText->text().toDouble();

    if(changeRateOfAscendingLongitudeText->text().isEmpty()) return false;
    else changeRateOfAscendingLongitude = changeRateOfAscendingLongitudeText->text().toDouble();

    if(adjustedOfAveAngularVText->text().isEmpty()) return false;
    else adjustedOfAveAngularV = adjustedOfAveAngularVText->text().toDouble();

    if(adjustedOfLatitudeArgCosText->text().isEmpty()) return false;
    else adjustedOfLatitudeArgCos = adjustedOfLatitudeArgCosText->text().toDouble();

    if(adjustedOfLatitudeArgSinText->text().isEmpty()) return false;
    else adjustedOfLatitudeArgSin = adjustedOfLatitudeArgSinText->text().toDouble();

    if(adjustedOfRadiusCosText->text().isEmpty()) return false;
    else adjustedOfRadiusCos = adjustedOfRadiusCosText->text().toDouble();

    if(adjustedOfRadiusSinText->text().isEmpty()) return false;
    else adjustedOfRadiusSin = adjustedOfRadiusSinText->text().toDouble();

    if(adjustedOfDipCosText->text().isEmpty()) return false;
    else adjustedOfDipCos = adjustedOfDipCosText->text().toDouble();

    if(adjustedOfDipSinText->text().isEmpty()) return false;
    else adjustedOfDipSin = adjustedOfDipSinText->text().toDouble();

    if(secondText->text().isEmpty()) return false;
    else second = secondText->text().toDouble();

    if(clockCorrection0Text->text().isEmpty()) return false;
    else clockCorrection0 = clockCorrection0Text->text().toDouble();

    if(clockCorrection1Text->text().isEmpty()) return false;
    else clockCorrection1 = clockCorrection1Text->text().toDouble();

    if(clockCorrection2Text->text().isEmpty()) return false;
    else clockCorrection2 = clockCorrection2Text->text().toDouble();

    return true;
}

void MainWindow::on_pushButton_clicked()
{
    if(!check())
    {
        QString dlgTitle="提示";
        QString strInfo="数据未完全填充";
        QMessageBox::warning(this, dlgTitle, strInfo);
    }
    else
    {
        caculate();
    }
}

void MainWindow::caculate()
{
    HalfLong();
    TrueAveAngularV();
    SatelliteClockError();
    EphemerisBeginTime();
    AveAnomaly();
    EccAnomaly();
    TruAnomaly();
    UpPFA();
    AdjustedOfUpPFA();
    AdjustedOfRadiusVector();
    AdjustedOfDip();
    TrueUpPFA();
    TrueRadiusVector();
    TrueDip();
    TrueAscendingLongitude();
    pos();
    ECEF();
}

void MainWindow::HalfLong()              //半轴长
{
    halfLong = sqrtHalfLong * sqrtHalfLong;
    halfLongText->setText(QString::number(halfLong));
}

void MainWindow::TrueAveAngularV()       //校正后的平均角速度
{
    trueAveAngularV = sqrt( EGC / pow(halfLong, 3)) + adjustedOfAveAngularV;
    trueAveAngularVText->setText(QString::number(trueAveAngularV));
}

void MainWindow::SatelliteClockError()   //卫星钟差
{
    satelliteClockError = clockCorrection0 + clockCorrection1 * (time - second) + clockCorrection2 * (time - second);
    satelliteClockErrorText->setText(QString::number(satelliteClockError));
}

void MainWindow::EphemerisBeginTime()    //从星历历元算起的时间
{
     ephemerisBeginTime = time - baseTime;
     ephemerisBeginTimeText->setText(QString::number(ephemerisBeginTime));
}

void MainWindow::AveAnomaly()            //平均近点角
{
    aveAnomaly = aveApproachAngle + trueAveAngularV * ephemerisBeginTime;
    aveAnomalyText->setText(QString::number(aveAnomaly));
}

void MainWindow::EccAnomaly()            //偏心近点角
{
    int times = 0;
    double last = aveAnomaly;
    eccAnomaly = aveAnomaly + eccentricity * sin(last);

    while(times<30)
    {
        last = eccAnomaly;
        eccAnomaly = aveAnomaly + eccentricity * sin(last);
        times++;
    }
    eccAnomalyText->setText(QString::number(eccAnomaly));
}

void MainWindow::TruAnomaly()            //真近点角
{
    double sinTruAnomaly = sqrt(1 - eccentricity * eccentricity) * sin(eccAnomaly) / (1 - eccentricity * cos(eccAnomaly));
    double cosTruAnomaly = (cos(eccAnomaly) - eccentricity) / (1 - eccentricity * cos(eccAnomaly));

    if (cosTruAnomaly == 0) {
        if (sinTruAnomaly > eccentricity)
            truAnomaly = PI / 2;
        else
            truAnomaly = -PI / 2;
    } else {
        truAnomaly = atan(sinTruAnomaly / cosTruAnomaly);
        if (cosTruAnomaly < 0) {
            if (sinTruAnomaly >= 0)
                truAnomaly += PI;
            else
                truAnomaly -= PI;
        }
    }

    truAnomalyText->setText(QString::number(truAnomaly));
}

void MainWindow::UpPFA()                 //升交距角
{
    upPFA = truAnomaly + perigeeArg;
    upPFAText->setText(QString::number(upPFA));
}

void MainWindow::AdjustedOfUpPFA()       //升交距角的校正值
{
    adjustedOfUpPFA = adjustedOfLatitudeArgSin * sin(2 * upPFA) + adjustedOfLatitudeArgCos * cos(2 * upPFA);
    adjustedOfUpPFAText->setText(QString::number(adjustedOfUpPFA));
}

void MainWindow::AdjustedOfRadiusVector()   //向径的校正值
{
    adjustedOfRadiusVector = adjustedOfRadiusSin * sin(2 * upPFA) + adjustedOfRadiusCos * cos(2 * upPFA);
    adjustedOfRadiusVectorText->setText(QString::number(adjustedOfRadiusVector));
}

void MainWindow::AdjustedOfDip()         //倾角的校正值
{
    adjustedOfDip = adjustedOfDipSin * sin(2 * upPFA) + adjustedOfDipCos * cos(2 * upPFA);
    adjustedOfDipText->setText(QString::number(adjustedOfDip));
}

void MainWindow::TrueUpPFA()             //校正后的升交距角
{
    trueUpPFA = upPFA + adjustedOfUpPFA;
    trueUpPFAText->setText(QString::number(trueUpPFA));
}

void MainWindow::TrueRadiusVector()      //校正后的向径
{
    trueRadiusVector = halfLong * (1 - eccentricity * cos(eccAnomaly)) + adjustedOfRadiusVector;
    trueRadiusVectorText->setText(QString::number(trueRadiusVector));
}

void MainWindow::TrueDip()
{
    trueDip = dip + changeRateOfdip * ephemerisBeginTime + adjustedOfDip;
    trueDipText->setText(QString::number(trueDip));
}

void MainWindow::TrueAscendingLongitude()
{
    trueAscendingLongitude = ascendingLongitude + changeRateOfAscendingLongitude * (time - baseTime) - RAV * time;
    trueAscendingLongitudeText->setText(QString::number(trueAscendingLongitude));
}

void MainWindow::pos()
{
    posX = trueRadiusVector * cos(trueUpPFA);
    posY = trueRadiusVector * sin(trueUpPFA);

    posXText->setText(QString::number(posX));
    posYText->setText(QString::number(posY));
}

void MainWindow::ECEF()
{
    double ECEFx = posX * cos(trueAscendingLongitude) - posY * cos(trueDip) * sin(trueAscendingLongitude);
    double ECEFy = posX * sin(trueAscendingLongitude) + posY * cos(trueDip) * cos(trueAscendingLongitude);
    double ECEFz = posY * sin(trueDip);

    ECEFxText->setText(QString::number(ECEFx));
    ECEFyText->setText(QString::number(ECEFy));
    ECEFzText->setText(QString::number(ECEFz));
}

void MainWindow::fillData()
{
    timeText->setText("4800");
    baseTimeText->setText("0.00000000000000000");
    sqrtHalfLongText->setText("5153.7127704599998");
    clockCorrection0Text->setText("0.00028600683435800001");
    clockCorrection1Text->setText("1.7053025658199999e-012");
    clockCorrection2Text->setText("0");
    adjustedOfAveAngularVText->setText("4.1115998360700002e-009");
    aveApproachAngleText->setText("1.2263973009600000");
    eccentricityText->setText("0.0053100715158500003");
    perigeeArgText->setText("-1.6819446292500000");
    adjustedOfLatitudeArgCosText->setText("-5.5264681577700003e-006");    // 纬度幅角余弦的校正值
    adjustedOfLatitudeArgSinText->setText("1.1192634701700000e-005");    // 纬度幅角正弦的校正值
    adjustedOfRadiusCosText->setText("175.34375000000000");  // 轨道半径余弦的校正值
    adjustedOfRadiusSinText->setText("-105.43750000000000");  // 轨道半径正弦的校正值
    adjustedOfDipCosText->setText("-9.6857547759999998e-008");    // 倾角余弦的校正值
    adjustedOfDipSinText->setText("-7.8231096267699997e-008");    // 倾角正弦的校正值
    ascendingLongitudeText->setText("-2.9080127721900002");
    changeRateOfAscendingLongitudeText->setText("-7.7124641122299999e-009");
    dipText->setText("0.97432927738800001");
    changeRateOfdipText->setText("1.8643633724999999e-010");
    secondText->setText("0");
}

void MainWindow::on_b_fillData_clicked()
{
    fillData();
}

