/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QLabel *label_31;
    QLineEdit *adjustedOfDipText;
    QLabel *label_16;
    QLabel *label_40;
    QLineEdit *ascendingLongitudeText;
    QLabel *label_5;
    QLabel *label_29;
    QLineEdit *truAnomalyText;
    QLabel *label_36;
    QLabel *label_19;
    QLineEdit *baseTimeText;
    QLineEdit *adjustedOfLatitudeArgCosText;
    QLineEdit *changeRateOfdipText;
    QLineEdit *aveAnomalyText;
    QLabel *label_7;
    QLabel *label_15;
    QLineEdit *clockCorrection2Text;
    QLabel *label_11;
    QLabel *label_39;
    QLineEdit *adjustedOfDipCosText;
    QLineEdit *ECEFyText;
    QLineEdit *trueAveAngularVText;
    QLineEdit *trueRadiusVectorText;
    QLabel *label;
    QLineEdit *eccentricityText;
    QLabel *label_25;
    QLineEdit *trueDipText;
    QLabel *label_23;
    QLineEdit *perigeeArgText;
    QLineEdit *timeText;
    QLabel *label_24;
    QLineEdit *clockCorrection1Text;
    QLineEdit *aveApproachAngleText;
    QLabel *label_41;
    QLineEdit *adjustedOfAveAngularVText;
    QLineEdit *posXText;
    QLineEdit *changeRateOfAscendingLongitudeText;
    QLabel *label_33;
    QLabel *label_22;
    QLabel *label_17;
    QLineEdit *dipText;
    QLineEdit *adjustedOfRadiusCosText;
    QLabel *label_26;
    QLineEdit *secondText;
    QLineEdit *adjustedOfRadiusSinText;
    QLabel *label_37;
    QLineEdit *adjustedOfDipSinText;
    QLabel *label_21;
    QLabel *label_28;
    QLabel *label_35;
    QLineEdit *clockCorrection0Text;
    QLineEdit *upPFAText;
    QLabel *label_2;
    QLabel *label_9;
    QLabel *label_10;
    QLineEdit *ephemerisBeginTimeText;
    QLineEdit *trueUpPFAText;
    QLineEdit *eccAnomalyText;
    QLineEdit *posYText;
    QLabel *label_18;
    QLabel *label_8;
    QLabel *label_38;
    QLabel *label_12;
    QLabel *label_6;
    QLineEdit *adjustedOfUpPFAText;
    QLabel *label_13;
    QLabel *label_3;
    QLineEdit *ECEFxText;
    QLineEdit *satelliteClockErrorText;
    QLabel *label_32;
    QLabel *label_4;
    QLineEdit *adjustedOfRadiusVectorText;
    QLabel *label_34;
    QLineEdit *trueAscendingLongitudeText;
    QLabel *label_20;
    QLabel *label_27;
    QLabel *label_30;
    QLineEdit *sqrtHalfLongText;
    QLineEdit *ECEFzText;
    QLabel *label_14;
    QLineEdit *halfLongText;
    QLineEdit *adjustedOfLatitudeArgSinText;
    QPushButton *b_fillData;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1092, 569);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_31 = new QLabel(centralwidget);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        gridLayout->addWidget(label_31, 11, 4, 1, 1);

        adjustedOfDipText = new QLineEdit(centralwidget);
        adjustedOfDipText->setObjectName(QString::fromUtf8("adjustedOfDipText"));

        gridLayout->addWidget(adjustedOfDipText, 12, 5, 1, 1);

        label_16 = new QLabel(centralwidget);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout->addWidget(label_16, 0, 2, 1, 1);

        label_40 = new QLabel(centralwidget);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        gridLayout->addWidget(label_40, 16, 2, 1, 1);

        ascendingLongitudeText = new QLineEdit(centralwidget);
        ascendingLongitudeText->setObjectName(QString::fromUtf8("ascendingLongitudeText"));

        gridLayout->addWidget(ascendingLongitudeText, 6, 5, 1, 1);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout->addWidget(label_5, 4, 0, 1, 1);

        label_29 = new QLabel(centralwidget);
        label_29->setObjectName(QString::fromUtf8("label_29"));

        gridLayout->addWidget(label_29, 13, 2, 1, 1);

        truAnomalyText = new QLineEdit(centralwidget);
        truAnomalyText->setObjectName(QString::fromUtf8("truAnomalyText"));

        gridLayout->addWidget(truAnomalyText, 12, 3, 1, 1);

        label_36 = new QLabel(centralwidget);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        gridLayout->addWidget(label_36, 14, 4, 1, 1);

        label_19 = new QLabel(centralwidget);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout->addWidget(label_19, 3, 2, 1, 1);

        baseTimeText = new QLineEdit(centralwidget);
        baseTimeText->setObjectName(QString::fromUtf8("baseTimeText"));

        gridLayout->addWidget(baseTimeText, 0, 1, 1, 1);

        adjustedOfLatitudeArgCosText = new QLineEdit(centralwidget);
        adjustedOfLatitudeArgCosText->setObjectName(QString::fromUtf8("adjustedOfLatitudeArgCosText"));

        gridLayout->addWidget(adjustedOfLatitudeArgCosText, 0, 3, 1, 1);

        changeRateOfdipText = new QLineEdit(centralwidget);
        changeRateOfdipText->setObjectName(QString::fromUtf8("changeRateOfdipText"));

        gridLayout->addWidget(changeRateOfdipText, 0, 5, 1, 1);

        aveAnomalyText = new QLineEdit(centralwidget);
        aveAnomalyText->setObjectName(QString::fromUtf8("aveAnomalyText"));

        gridLayout->addWidget(aveAnomalyText, 10, 3, 1, 1);

        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout->addWidget(label_7, 6, 0, 1, 1);

        label_15 = new QLabel(centralwidget);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout->addWidget(label_15, 5, 0, 1, 1);

        clockCorrection2Text = new QLineEdit(centralwidget);
        clockCorrection2Text->setObjectName(QString::fromUtf8("clockCorrection2Text"));

        gridLayout->addWidget(clockCorrection2Text, 5, 5, 1, 1);

        label_11 = new QLabel(centralwidget);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout->addWidget(label_11, 3, 4, 1, 1);

        label_39 = new QLabel(centralwidget);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        gridLayout->addWidget(label_39, 16, 0, 1, 1);

        adjustedOfDipCosText = new QLineEdit(centralwidget);
        adjustedOfDipCosText->setObjectName(QString::fromUtf8("adjustedOfDipCosText"));

        gridLayout->addWidget(adjustedOfDipCosText, 4, 3, 1, 1);

        ECEFyText = new QLineEdit(centralwidget);
        ECEFyText->setObjectName(QString::fromUtf8("ECEFyText"));

        gridLayout->addWidget(ECEFyText, 16, 3, 1, 1);

        trueAveAngularVText = new QLineEdit(centralwidget);
        trueAveAngularVText->setObjectName(QString::fromUtf8("trueAveAngularVText"));

        gridLayout->addWidget(trueAveAngularVText, 11, 1, 1, 1);

        trueRadiusVectorText = new QLineEdit(centralwidget);
        trueRadiusVectorText->setObjectName(QString::fromUtf8("trueRadiusVectorText"));

        gridLayout->addWidget(trueRadiusVectorText, 14, 1, 1, 1);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        eccentricityText = new QLineEdit(centralwidget);
        eccentricityText->setObjectName(QString::fromUtf8("eccentricityText"));

        gridLayout->addWidget(eccentricityText, 3, 1, 1, 1);

        label_25 = new QLabel(centralwidget);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        gridLayout->addWidget(label_25, 13, 0, 1, 1);

        trueDipText = new QLineEdit(centralwidget);
        trueDipText->setObjectName(QString::fromUtf8("trueDipText"));

        gridLayout->addWidget(trueDipText, 14, 3, 1, 1);

        label_23 = new QLabel(centralwidget);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout->addWidget(label_23, 11, 0, 1, 1);

        perigeeArgText = new QLineEdit(centralwidget);
        perigeeArgText->setObjectName(QString::fromUtf8("perigeeArgText"));

        gridLayout->addWidget(perigeeArgText, 1, 5, 1, 1);

        timeText = new QLineEdit(centralwidget);
        timeText->setObjectName(QString::fromUtf8("timeText"));

        gridLayout->addWidget(timeText, 1, 1, 1, 1);

        label_24 = new QLabel(centralwidget);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout->addWidget(label_24, 12, 0, 1, 1);

        clockCorrection1Text = new QLineEdit(centralwidget);
        clockCorrection1Text->setObjectName(QString::fromUtf8("clockCorrection1Text"));

        gridLayout->addWidget(clockCorrection1Text, 4, 5, 1, 1);

        aveApproachAngleText = new QLineEdit(centralwidget);
        aveApproachAngleText->setObjectName(QString::fromUtf8("aveApproachAngleText"));

        gridLayout->addWidget(aveApproachAngleText, 6, 3, 1, 1);

        label_41 = new QLabel(centralwidget);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        gridLayout->addWidget(label_41, 16, 4, 1, 1);

        adjustedOfAveAngularVText = new QLineEdit(centralwidget);
        adjustedOfAveAngularVText->setObjectName(QString::fromUtf8("adjustedOfAveAngularVText"));

        gridLayout->addWidget(adjustedOfAveAngularVText, 6, 1, 1, 1);

        posXText = new QLineEdit(centralwidget);
        posXText->setObjectName(QString::fromUtf8("posXText"));

        gridLayout->addWidget(posXText, 15, 1, 1, 1);

        changeRateOfAscendingLongitudeText = new QLineEdit(centralwidget);
        changeRateOfAscendingLongitudeText->setObjectName(QString::fromUtf8("changeRateOfAscendingLongitudeText"));

        gridLayout->addWidget(changeRateOfAscendingLongitudeText, 5, 1, 1, 1);

        label_33 = new QLabel(centralwidget);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        gridLayout->addWidget(label_33, 13, 4, 1, 1);

        label_22 = new QLabel(centralwidget);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout->addWidget(label_22, 10, 0, 1, 1);

        label_17 = new QLabel(centralwidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout->addWidget(label_17, 1, 2, 1, 1);

        dipText = new QLineEdit(centralwidget);
        dipText->setObjectName(QString::fromUtf8("dipText"));

        gridLayout->addWidget(dipText, 4, 1, 1, 1);

        adjustedOfRadiusCosText = new QLineEdit(centralwidget);
        adjustedOfRadiusCosText->setObjectName(QString::fromUtf8("adjustedOfRadiusCosText"));

        gridLayout->addWidget(adjustedOfRadiusCosText, 2, 3, 1, 1);

        label_26 = new QLabel(centralwidget);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout->addWidget(label_26, 10, 2, 1, 1);

        secondText = new QLineEdit(centralwidget);
        secondText->setObjectName(QString::fromUtf8("secondText"));

        gridLayout->addWidget(secondText, 2, 5, 1, 1);

        adjustedOfRadiusSinText = new QLineEdit(centralwidget);
        adjustedOfRadiusSinText->setObjectName(QString::fromUtf8("adjustedOfRadiusSinText"));

        gridLayout->addWidget(adjustedOfRadiusSinText, 3, 3, 1, 1);

        label_37 = new QLabel(centralwidget);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        gridLayout->addWidget(label_37, 15, 0, 1, 1);

        adjustedOfDipSinText = new QLineEdit(centralwidget);
        adjustedOfDipSinText->setObjectName(QString::fromUtf8("adjustedOfDipSinText"));

        gridLayout->addWidget(adjustedOfDipSinText, 5, 3, 1, 1);

        label_21 = new QLabel(centralwidget);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        gridLayout->addWidget(label_21, 5, 2, 1, 1);

        label_28 = new QLabel(centralwidget);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        gridLayout->addWidget(label_28, 12, 2, 1, 1);

        label_35 = new QLabel(centralwidget);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        gridLayout->addWidget(label_35, 14, 2, 1, 1);

        clockCorrection0Text = new QLineEdit(centralwidget);
        clockCorrection0Text->setObjectName(QString::fromUtf8("clockCorrection0Text"));

        gridLayout->addWidget(clockCorrection0Text, 3, 5, 1, 1);

        upPFAText = new QLineEdit(centralwidget);
        upPFAText->setObjectName(QString::fromUtf8("upPFAText"));

        gridLayout->addWidget(upPFAText, 13, 3, 1, 1);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        label_9 = new QLabel(centralwidget);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout->addWidget(label_9, 1, 4, 1, 1);

        label_10 = new QLabel(centralwidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout->addWidget(label_10, 2, 4, 1, 1);

        ephemerisBeginTimeText = new QLineEdit(centralwidget);
        ephemerisBeginTimeText->setObjectName(QString::fromUtf8("ephemerisBeginTimeText"));

        gridLayout->addWidget(ephemerisBeginTimeText, 13, 1, 1, 1);

        trueUpPFAText = new QLineEdit(centralwidget);
        trueUpPFAText->setObjectName(QString::fromUtf8("trueUpPFAText"));

        gridLayout->addWidget(trueUpPFAText, 13, 5, 1, 1);

        eccAnomalyText = new QLineEdit(centralwidget);
        eccAnomalyText->setObjectName(QString::fromUtf8("eccAnomalyText"));

        gridLayout->addWidget(eccAnomalyText, 11, 3, 1, 1);

        posYText = new QLineEdit(centralwidget);
        posYText->setObjectName(QString::fromUtf8("posYText"));

        gridLayout->addWidget(posYText, 15, 3, 1, 1);

        label_18 = new QLabel(centralwidget);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout->addWidget(label_18, 2, 2, 1, 1);

        label_8 = new QLabel(centralwidget);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout->addWidget(label_8, 6, 2, 1, 1);

        label_38 = new QLabel(centralwidget);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        gridLayout->addWidget(label_38, 15, 2, 1, 1);

        label_12 = new QLabel(centralwidget);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout->addWidget(label_12, 4, 4, 1, 1);

        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout->addWidget(label_6, 6, 4, 1, 1);

        adjustedOfUpPFAText = new QLineEdit(centralwidget);
        adjustedOfUpPFAText->setObjectName(QString::fromUtf8("adjustedOfUpPFAText"));

        gridLayout->addWidget(adjustedOfUpPFAText, 10, 5, 1, 1);

        label_13 = new QLabel(centralwidget);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout->addWidget(label_13, 5, 4, 1, 1);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        ECEFxText = new QLineEdit(centralwidget);
        ECEFxText->setObjectName(QString::fromUtf8("ECEFxText"));

        gridLayout->addWidget(ECEFxText, 16, 1, 1, 1);

        satelliteClockErrorText = new QLineEdit(centralwidget);
        satelliteClockErrorText->setObjectName(QString::fromUtf8("satelliteClockErrorText"));

        gridLayout->addWidget(satelliteClockErrorText, 12, 1, 1, 1);

        label_32 = new QLabel(centralwidget);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        gridLayout->addWidget(label_32, 12, 4, 1, 1);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout->addWidget(label_4, 3, 0, 1, 1);

        adjustedOfRadiusVectorText = new QLineEdit(centralwidget);
        adjustedOfRadiusVectorText->setObjectName(QString::fromUtf8("adjustedOfRadiusVectorText"));

        gridLayout->addWidget(adjustedOfRadiusVectorText, 11, 5, 1, 1);

        label_34 = new QLabel(centralwidget);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        gridLayout->addWidget(label_34, 14, 0, 1, 1);

        trueAscendingLongitudeText = new QLineEdit(centralwidget);
        trueAscendingLongitudeText->setObjectName(QString::fromUtf8("trueAscendingLongitudeText"));

        gridLayout->addWidget(trueAscendingLongitudeText, 14, 5, 1, 1);

        label_20 = new QLabel(centralwidget);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout->addWidget(label_20, 4, 2, 1, 1);

        label_27 = new QLabel(centralwidget);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        gridLayout->addWidget(label_27, 11, 2, 1, 1);

        label_30 = new QLabel(centralwidget);
        label_30->setObjectName(QString::fromUtf8("label_30"));

        gridLayout->addWidget(label_30, 10, 4, 1, 1);

        sqrtHalfLongText = new QLineEdit(centralwidget);
        sqrtHalfLongText->setObjectName(QString::fromUtf8("sqrtHalfLongText"));

        gridLayout->addWidget(sqrtHalfLongText, 2, 1, 1, 1);

        ECEFzText = new QLineEdit(centralwidget);
        ECEFzText->setObjectName(QString::fromUtf8("ECEFzText"));

        gridLayout->addWidget(ECEFzText, 16, 5, 1, 1);

        label_14 = new QLabel(centralwidget);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout->addWidget(label_14, 0, 4, 1, 1);

        halfLongText = new QLineEdit(centralwidget);
        halfLongText->setObjectName(QString::fromUtf8("halfLongText"));

        gridLayout->addWidget(halfLongText, 10, 1, 1, 1);

        adjustedOfLatitudeArgSinText = new QLineEdit(centralwidget);
        adjustedOfLatitudeArgSinText->setObjectName(QString::fromUtf8("adjustedOfLatitudeArgSinText"));

        gridLayout->addWidget(adjustedOfLatitudeArgSinText, 1, 3, 1, 1);

        b_fillData = new QPushButton(centralwidget);
        b_fillData->setObjectName(QString::fromUtf8("b_fillData"));
        b_fillData->setMinimumSize(QSize(0, 49));
        QFont font;
        font.setPointSize(10);
        b_fillData->setFont(font);
        b_fillData->setMouseTracking(false);
        b_fillData->setToolTipDuration(-1);

        gridLayout->addWidget(b_fillData, 7, 0, 1, 2);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(0, 49));
        pushButton->setFont(font);

        gridLayout->addWidget(pushButton, 7, 3, 1, 2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1092, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        label_31->setText(QCoreApplication::translate("MainWindow", "\345\220\221\345\276\204\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "\345\257\271\347\272\254\345\272\246\345\271\205\350\247\222\344\275\231\345\274\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_40->setText(QCoreApplication::translate("MainWindow", "ECEFy\345\235\220\346\240\207", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\345\200\276\350\247\222", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "\345\215\207\344\272\244\350\267\235\350\247\222", nullptr));
        label_36->setText(QCoreApplication::translate("MainWindow", "\347\273\217\346\240\241\346\255\243\347\232\204\345\215\207\344\272\244\347\202\271\347\273\217\345\272\246", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "\345\257\271\350\275\250\351\201\223\345\215\212\345\276\204\346\255\243\345\274\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "\345\271\263\345\235\207\350\247\222\351\200\237\345\272\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "\345\215\207\344\272\244\347\202\271\347\273\217\345\272\246\345\217\230\345\214\226\347\216\207", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "\346\227\266\351\222\237\344\277\256\346\255\2430", nullptr));
        label_39->setText(QCoreApplication::translate("MainWindow", "ECEFx\345\235\220\346\240\207", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\346\230\237\345\216\206\345\237\272\345\207\206\346\227\266\351\227\264", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "\346\230\237\345\216\206\350\265\267\347\256\227\346\227\266\351\227\264(\345\275\222\345\214\226\346\227\266\351\227\264)", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "\347\273\217\346\240\241\346\255\243\347\232\204\345\271\263\345\235\207\350\247\222\351\200\237\345\272\246", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "\345\215\253\346\230\237\351\222\237\345\267\256", nullptr));
        label_41->setText(QCoreApplication::translate("MainWindow", "ECEFz\345\235\220\346\240\207", nullptr));
        label_33->setText(QCoreApplication::translate("MainWindow", "\346\240\241\346\255\243\345\220\216\347\232\204\345\215\207\344\272\244\350\267\235\350\247\222", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "\345\215\212\351\225\277\350\275\264", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "\345\257\271\347\272\254\345\272\246\345\271\205\350\247\222\346\255\243\345\274\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "\345\271\263\345\235\207\350\277\221\347\202\271\350\247\222", nullptr));
        label_37->setText(QCoreApplication::translate("MainWindow", "\350\275\250\351\201\223\345\271\263\351\235\242\344\270\255X\344\275\215\347\275\256", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "\345\257\271\345\200\276\350\247\222\346\255\243\345\274\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "\347\234\237\350\277\221\347\202\271\350\247\222", nullptr));
        label_35->setText(QCoreApplication::translate("MainWindow", "\347\273\217\346\240\241\346\255\243\345\220\216\347\232\204\345\200\276\350\247\222", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\350\247\202\346\265\213\346\227\266\351\227\264", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\350\277\221\345\234\260\347\202\271\345\271\205\350\247\222", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "\347\247\222\346\225\260\346\215\256", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "\345\257\271\350\275\250\351\201\223\345\215\212\345\276\204\344\275\231\345\274\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "\346\230\237\345\216\206\345\237\272\345\207\206\346\227\266\351\227\264\347\232\204\345\271\263\345\235\207\350\277\221\347\202\271\350\247\222", nullptr));
        label_38->setText(QCoreApplication::translate("MainWindow", "\350\275\250\351\201\223\345\271\263\351\235\242\344\270\255Y\344\275\215\347\275\256", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "\346\227\266\351\222\237\344\277\256\346\255\2431", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "\345\215\207\344\272\244\347\202\271\347\273\217\345\272\246", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "\346\227\266\351\222\237\344\277\256\346\255\2432", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\350\275\250\351\201\223\345\215\212\351\225\277\350\275\264\345\271\263\346\226\271\346\240\271", nullptr));
        label_32->setText(QCoreApplication::translate("MainWindow", "\345\200\276\350\247\222\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\350\275\250\351\201\223\347\246\273\345\277\203\347\216\207", nullptr));
        label_34->setText(QCoreApplication::translate("MainWindow", "\346\240\241\346\255\243\345\220\216\347\232\204\345\220\221\345\276\204", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "\345\257\271\345\200\276\350\247\222\344\275\231\345\274\246\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "\345\201\217\345\277\203\350\277\221\347\202\271\350\247\222", nullptr));
        label_30->setText(QCoreApplication::translate("MainWindow", "\345\215\207\344\272\244\350\267\235\350\247\222\347\232\204\346\240\241\346\255\243\345\200\274", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "\345\200\276\350\247\222\345\217\230\345\214\226\347\216\207", nullptr));
        b_fillData->setText(QCoreApplication::translate("MainWindow", "\345\241\253\345\205\205\351\273\230\350\256\244\346\225\260\346\215\256", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\350\256\241\347\256\227\346\225\260\346\215\256", nullptr));
        (void)MainWindow;
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
